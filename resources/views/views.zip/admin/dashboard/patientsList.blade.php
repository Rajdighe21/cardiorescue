@extends('admin.dashboard.app')



@section('content')

<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Patint's List</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active">Patient's List</li>
                </ol>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>

<section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Patient Name</th>
                  <th>Patient Email</th>
                  <th>Contact</th>
                  <th>Engine version</th>
                  <th>CSS grade</th>
                </tr>
                </thead>
                <tbody>
               @foreach ($patientsLists as $patientsList)
               <tr>
                <td>{{$patientsList->patientname}}</td>
                <td>{{$patientsList->patientemail}}</td>
                <td>{{$patientsList->patientphone}}</td>
                <td>5</td>
                <td>C</td>
              </tr>
               @endforeach
                
               
                </tbody>
               
              </table>
           

            </div>
            <!-- /.card-body -->
            
          </div>
          <!-- /.card -->
          {{ $patientsLists->links() }}
       
         
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>

@endsection